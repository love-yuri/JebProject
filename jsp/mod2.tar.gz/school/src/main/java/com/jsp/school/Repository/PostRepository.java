package com.jsp.school.Repository;

import com.jsp.school.entity.Post;
import com.jsp.school.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Post, Integer> {
    Post findByName(String name);
}
