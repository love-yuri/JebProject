package com.jsp.school.Repository;

import com.jsp.school.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ResumeRepository extends JpaRepository<Resume, Integer> {
    List<Resume> findAllByJobIntent(String jobIntent);
}
