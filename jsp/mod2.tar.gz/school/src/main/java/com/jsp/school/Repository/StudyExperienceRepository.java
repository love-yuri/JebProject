package com.jsp.school.Repository;

import com.jsp.school.entity.Resume;
import com.jsp.school.entity.StudyExperience;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StudyExperienceRepository extends JpaRepository<StudyExperience, Integer> {
    List<StudyExperience> findAllByResumeId(Integer id);
}
