package com.jsp.school.controller;

import com.jsp.school.result.Doughnut;
import com.jsp.school.result.R;
import com.jsp.school.service.CountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("count")
@CrossOrigin
public class CountController {
    @Autowired
    private CountService countService;
    @PostMapping("highestEducation/{jobIntent}")
    public R<Doughnut> count(@PathVariable String jobIntent) {
        return countService.countHighestEducation(jobIntent);
    }

    @PostMapping("sex/{jobIntent}")
    public R<Doughnut> sexCount(@PathVariable String jobIntent) {
        return countService.sexCount(jobIntent);
    }

    @PostMapping("graduateYear/{jobIntent}")
    public R<Doughnut> graduateSchoolCount(@PathVariable String jobIntent) {
        return countService.graduateYearCount(jobIntent);
    }
}
