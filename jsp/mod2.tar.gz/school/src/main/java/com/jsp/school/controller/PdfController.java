package com.jsp.school.controller;


import ch.qos.logback.core.model.Model;
import com.jsp.school.result.ExtractString;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import com.jsp.school.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/pdf")
@CrossOrigin
public class PdfController {

    @Autowired
    private PdfService pdfService;
    @PostMapping("extract")
    public R<ResumeInfo> extract(@RequestPart(value = "file") MultipartFile file, Model model) {
        return pdfService.extract(file);
    }

    @PostMapping("extract/text")
    public R<ResumeInfo> extractText(@RequestBody ExtractString text) {
        return pdfService.extract(text.getData());
    }
}
