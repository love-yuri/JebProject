package com.jsp.school.controller;


import ch.qos.logback.core.model.Model;
import com.jsp.school.entity.Post;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import com.jsp.school.service.PdfService;
import com.jsp.school.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("post")
@CrossOrigin
public class PostController {

    @Autowired
    private PostService postService;
    @PostMapping("all")
    public R<List<Post>> all() {
        return postService.all();
    }

    @PostMapping("add")
    public R<Integer> addPost(@RequestBody Post post) {
        return postService.addPost(post);
    }
}
