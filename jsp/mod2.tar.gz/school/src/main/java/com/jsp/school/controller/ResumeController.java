package com.jsp.school.controller;

import ch.qos.logback.core.model.Model;
import com.jsp.school.entity.Resume;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import com.jsp.school.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/resume")
@CrossOrigin
public class ResumeController {
    @Autowired
    private ResumeService resumeService;

    /**
     * 删除简历
     * @param id
     * @return
     */
    @PostMapping("delete/{id}")
    public R<Boolean> delete(@PathVariable Integer id) {
        return resumeService.deleteResume(id);
    }

    @PostMapping("all")
    public R<List<ResumeInfo>> all() {
        return resumeService.all();
    }

}
