package com.jsp.school.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "post")
public class Post {
    @Id
    @GeneratedValue
    private Integer id; // 主键id

    /**
     * 姓名
     */
    @Column(name = "name")
    private String name;
}
