package com.jsp.school.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "resume")
public class Resume {
    @Id
    @GeneratedValue
    private Integer id; // 主键id

    /**
     * 姓名
     */
    @Column(name = "name")
    private String name;

    /**
     * 性别
     */
    @Column(name = "gender")
    private String gender;

    /**
     * 年龄
     */
    @Column(name = "age")
    private int age;

    /**
     * 求职意向
     */
    @Column(name = "job_intent")
    private String jobIntent;

    /**
     * 最高学历
     */
    @Column(name = "highest_education")
    private String highestEducation;

    /**
     * 毕业院校
     */
    @Column(name = "graduate_school")
    private String graduateSchool;

    /**
     * 毕业年份
     */
    @Column(name = "graduate_yuri")
    private String graduateYear;

}
