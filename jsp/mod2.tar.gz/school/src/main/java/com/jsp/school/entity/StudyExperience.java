package com.jsp.school.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "work_experience")
public class StudyExperience {
    @Id
    @GeneratedValue
    private Integer id; // 主键id

    /**
     * 简历id
     */
    @Column(name = "resume_id")
    private Integer resumeId;

    /**
     * 学习开始年份
     */
    @Column(name = "start_year")
    private String startYear;

    /**
     * 学习结束年份
     */
    @Column(name = "end_year")
    private String endYear;

    /**
     * 学校名称
     */
    @Column(name = "school")
    private String school;

    /**
     * 专业名称
     */
    @Column(name = "major")
    private String major;
}
