package com.jsp.school.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "study_experience")
public class WorkExperience {
    @Id
    @GeneratedValue
    private Integer id; // 主键id

    /**
     * 简历id
     */
    @Column(name = "resume_id")
    private Integer resumeId;

    /**
     * 工作开始年份
     */
    @Column(name = "start_year")
    private String startYear;

    /**
     * 工作结束年份
     */
    @Column(name = "end_year")
    private String endYear;

    /**
     * 公司名称
     */
    @Column(name = "company")
    private String company;

    /**
     * 岗位名称
     */
    @Column(name = "post_name")
    private String postName;
}
