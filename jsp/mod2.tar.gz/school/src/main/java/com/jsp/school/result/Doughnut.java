package com.jsp.school.result;

import lombok.Data;

import java.util.List;

@Data
public class Doughnut {
    private List<Dataset> datasets;
    private List<String> labels;
    @Data
    public static class Dataset {
        private List<Integer> data;
    }
}
