package com.jsp.school.result;

import lombok.Data;

@Data
public class ExtractString {
    private String data;
}
