package com.jsp.school.result;

import com.jsp.school.entity.StudyExperience;
import com.jsp.school.entity.WorkExperience;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

import java.util.List;

@Data
public class ResumeInfo {
    /**
     * 简历主键
     */
    private Integer id;

    /**
     * 姓名
     */
    private String name;

    /**
     * 性别
     */
    private String gender;

    /**
     * 年龄
     */
    private int age;

    /**
     * 求职意向
     */
    private String jobIntent;

    /**
     * 最高学历
     */
    private String highestEducation;

    /**
     * 毕业院校
     */
    private String graduateSchool;

    /**
     * 毕业年份
     */
    private String graduateYear;

    /**
     * 工作经历
     */
    private List<WorkExperience> workExperiences;

    /**
     * 学习经历
     */
    private List<StudyExperience> studyExperiences;
}
