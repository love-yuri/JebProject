package com.jsp.school.service;

import com.jsp.school.entity.Resume;
import com.jsp.school.result.Doughnut;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class CountService {
    @Autowired
    private ResumeService resumeService;

    /**
     * 学历统计
     */
    public R<Doughnut> countHighestEducation(String jobIntent) {
        List<ResumeInfo> infos = getAllResumeInfo(jobIntent);
        Doughnut doughnut = new Doughnut();
        Map<String, Integer> map = new HashMap<>();
        infos.forEach(info -> map.merge(info.getHighestEducation(), 1,  (v1, v2) -> v1 + 1));
        count(map, doughnut);
        return R.success(doughnut);
    }

    /**
     * 性别统计
     */
    public R<Doughnut> sexCount(String jobIntent) {
        List<ResumeInfo> infos = getAllResumeInfo(jobIntent);
        Doughnut doughnut = new Doughnut();
        Map<String, Integer> map = new HashMap<>();
        infos.forEach(info -> map.merge(info.getGender(), 1,  (v1, v2) -> v1 + 1));
        count(map, doughnut);
        return R.success(doughnut);
    }

    /**
     * 毕业年份统计
     */
    public R<Doughnut> graduateYearCount(String jobIntent) {
        List<ResumeInfo> infos = getAllResumeInfo(jobIntent);
        Doughnut doughnut = new Doughnut();
        Map<String, Integer> map = new HashMap<>();
        infos.forEach(info -> map.merge(info.getGraduateYear(), 1,  (v1, v2) -> v1 + 1));
        count(map, doughnut);
        return R.success(doughnut);
    }

    /**
     * 统计
     */
    public void count(Map<String, Integer> map, Doughnut doughnut) {
        Doughnut.Dataset dataset = new Doughnut.Dataset();
        List<Integer> data = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        List<Doughnut.Dataset> datasets = new ArrayList<>();
        map.forEach((k, v) -> {
            data.add(v);
            labels.add(k);
        });
        dataset.setData(data);
        doughnut.setLabels(labels);
        datasets.add(dataset);
        doughnut.setDatasets(datasets);
    }

    /**
     * 根据意向获取所有简历信息
     */
    public List<ResumeInfo> getAllResumeInfo(String jobIntent) {
        List<Resume> resumes = resumeService.findAllByJobIntent(jobIntent);
        List<ResumeInfo> infos = new ArrayList<>();
        resumes.forEach(resume -> {
            ResumeInfo resumeInfo = resumeService.getResumeInfo(resume);
            infos.add(resumeInfo);
        });
        return infos;
    }
}
