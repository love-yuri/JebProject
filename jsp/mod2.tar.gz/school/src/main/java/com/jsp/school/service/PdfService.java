package com.jsp.school.service;

import com.jsp.school.Repository.PostRepository;
import com.jsp.school.Repository.ResumeRepository;
import com.jsp.school.Repository.StudyExperienceRepository;
import com.jsp.school.Repository.WorkExperienceRepository;
import com.jsp.school.entity.Post;
import com.jsp.school.entity.Resume;
import com.jsp.school.entity.StudyExperience;
import com.jsp.school.entity.WorkExperience;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class PdfService {
    @Autowired
    private ResumeRepository resumeRepository;
    @Autowired
    private WorkExperienceRepository workExperienceRepository;
    @Autowired
    private StudyExperienceRepository studyExperienceRepository;
    @Autowired
    private PostRepository postRepository;

    public R<ResumeInfo> extract(MultipartFile file) {
        try {
            try (PDDocument document = Loader.loadPDF(file.getBytes())) {
                PDFTextStripper stripper = new PDFTextStripper();
                return(extract(stripper.getText(document)));
            }
        } catch (IOException e) {
            return R.error(null, e.getLocalizedMessage());
        }
    }

    /**
     * 提取个人信息
     */
    public R<ResumeInfo> extract(String str) {
        Resume resume = new Resume();
        resume.setName(match(str, "姓 *名 *[:：]* *([\\u4e00-\\u9fa5]*)", 1));
        resume.setAge(extractBirthDay(str));
        resume.setGender(match(str, "性 *别 *[:：]* *([\\u4e00-\\u9fa5])", 1));
        resume.setJobIntent(match(str, "求 *职 *意 *向 *[:：\\s]* *([\\u4e00-\\u9fa5]*)", 1));
        resume.setGraduateYear(match(str, "毕 *业 *年 *份 *[:：\\s]* *(\\d{4})", 1));
        resume.setHighestEducation(match(str, "最* *高* *学 *历 *[:：]* *(本科|专科|小学|初中|高中|中职|高职|研究生|博士)", 1));
        resume.setGraduateSchool(extractSchool(str));
        resumeRepository.save(resume);
        log.info("resume -> {}", resume);
        extractTime(str, "(\\d{4})[./]*\\d* *[—-]* *(\\d{4})[./]*\\d*", resume);
        extractTime(str, "(\\d{4})[./]*\\d* *[—-]* *(至今)", resume);
        Post post = postRepository.findByName(resume.getJobIntent());
        if(post == null) {
            post = new Post();
            post.setName(resume.getJobIntent());
            postRepository.save(post);
        }
        return R.success(getResumeInfo(resume));
    }

    /**
     * 提取出生日期
     */
    public int extractBirthDay(String str) {
        String birth = match(str, "年 *龄 *[:|：]* *([0-9]{1,3})", 1);
        birth = birth == null ? match(str, "出生[\\u4e00-\\u9fa5]{2} *[:|：] *(\\d{4})", 1) : birth;
        birth = birth == null ? match(str, "生 *日 *[:：] *(\\d{4})", 1) : birth;
        if(birth == null) {
            return 0;
        }
        return Integer.parseInt(birth);
    }

    /**
     * 提取毕业院校
     */
    public String extractSchool(String str) {
        String school = match(str, "毕 *业 *院 *校 *[:：]* *([\\u4e00-\\u9fa5]*)", 1);
        school = school == null? match(str, "毕业院校 *[:：\\s]* *([\\u4e00-\\u9fa5]*)", 1) : school;
        return school;
    }

    /**
     * 根据时间段提取重要信息
     * @param str 需要提取的字符串
     * @param patternStr 正则表达式
     * @param resume 简历信息
     */
    public void extractTime(String str, String patternStr, Resume resume) {
        Pattern pattern = Pattern.compile(patternStr);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            String s = matcher.group(0);
            int index = str.indexOf(s) + s.length();
            String string = str.substring(index, str.indexOf("\n", index));
            if(match(string, "本科|专科|小学|初中|高中|中职|高职|研究生|博士|大学|学院|学校", 0) != null
                && match(string, "会长|社团|学社|部长|社长", 0) == null) {
                extractStudy(string, resume, matcher.group(1), matcher.group(2));
                continue;
            }
            if(match(string, "公司", 0) != null) {
                extractWork(string, resume, matcher.group(1), matcher.group(2));
            }
        }
    }

    /**
     * 提取工作经历
     * @param str 需要提取的字符串
     * @param resume 简历
     * @param start 开始时间
     * @param end 结束时间
     */
    public void extractWork(String str, Resume resume, String start, String end) {
        Pattern pattern = Pattern.compile(" *([\\u4e00-\\u9fa5a-zA-Z]*) *([\\u4e00-\\u9fa5a-zA-Z]*) *");
        Matcher matcher = pattern.matcher(str);
        if(matcher.find()) {
            WorkExperience workExperience = new WorkExperience();
            workExperience.setStartYear(start);
            workExperience.setEndYear(end);
            workExperience.setCompany(matcher.group(1));
            workExperience.setPostName(matcher.group(2));
            workExperience.setResumeId(resume.getId());
            workExperienceRepository.save(workExperience);
            log.info("工作经历 -> {}", workExperience);
        }
    }

    /**
     * 提取学习经历
     * @param str 需要提取的字符串
     * @param resume 简历
     * @param start 开始时间
     * @param end 结束时间
     */
    public void extractStudy(String str, Resume resume, String start, String end) {
        Pattern pattern = Pattern.compile(" *([\\u4e00-\\u9fa5a-zA-Z]*) *([\\u4e00-\\u9fa5a-zA-Z]*) *");
        Matcher matcher = pattern.matcher(str);
        if(matcher.find()) {
            StudyExperience studyExperience = new StudyExperience();
            studyExperience.setStartYear(start);
            studyExperience.setEndYear(end);
            studyExperience.setSchool(matcher.group(1));
            studyExperience.setMajor(matcher.group(2));
            studyExperience.setResumeId(resume.getId());
            studyExperienceRepository.save(studyExperience);
            if(resume.getGraduateSchool() == null) {
                resume.setGraduateSchool(matcher.group(1));
                resumeRepository.save(resume);
            }
            if(resume.getGraduateYear() == null) {
                resume.setGraduateYear(end);
                resumeRepository.save(resume);
            }
            log.info("学习经历 -> {}", studyExperience);
        }
    }

    /**
     * 正则匹配
     * @param str 需要提取的字符串
     * @param namePattern 正则表达式
     * @param group 待提取的组
     * @return 返回匹配的字符串
     */
    public String match(String str, String namePattern, int group) {
        Pattern pattern = Pattern.compile(namePattern);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            return matcher.group(group);
        } else {
            return null;
        }
    }

    /**
     * 根据简历获取简历信息
     */
    public ResumeInfo getResumeInfo(Resume resume) {
        ResumeInfo resumeInfo = new ResumeInfo();
        /* 拷贝简历信息 */
        resumeInfo.setId(resume.getId());
        resumeInfo.setName(resume.getName());
        resumeInfo.setGender(resume.getGender());
        resumeInfo.setAge(resume.getAge());
        resumeInfo.setJobIntent(resume.getJobIntent());
        resumeInfo.setGraduateYear(resume.getGraduateYear());
        resumeInfo.setHighestEducation(resume.getHighestEducation());
        resumeInfo.setGraduateSchool(resume.getGraduateSchool());
        resumeInfo.setStudyExperiences(studyExperienceRepository.findAllByResumeId(resume.getId()));
        resumeInfo.setWorkExperiences(workExperienceRepository.findAllByResumeId(resume.getId()));
        return resumeInfo;
    }
}
