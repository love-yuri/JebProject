package com.jsp.school.service;

import com.jsp.school.Repository.PostRepository;
import com.jsp.school.entity.Post;
import com.jsp.school.result.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class PostService {
    @Autowired
    private PostRepository postRepository;
    public R<List<Post>> all() {
        return R.success(postRepository.findAll());
    }

    public R<Integer> addPost(Post post) {
        Post p = postRepository.findByName(post.getName());
        if(p != null) {
            return R.error(1, "该岗位已经存在");
        }
        postRepository.save(post);
        return R.success(post.getId());
    }
}
