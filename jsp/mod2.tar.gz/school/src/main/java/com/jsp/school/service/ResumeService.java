package com.jsp.school.service;

import com.jsp.school.Repository.PostRepository;
import com.jsp.school.Repository.ResumeRepository;
import com.jsp.school.Repository.StudyExperienceRepository;
import com.jsp.school.Repository.WorkExperienceRepository;
import com.jsp.school.entity.Resume;
import com.jsp.school.result.R;
import com.jsp.school.result.ResumeInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ResumeService {
    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private WorkExperienceRepository workExperienceRepository;

    @Autowired
    private StudyExperienceRepository studyExperienceRepository;

    /**
     * 删除简历
     */
    public R<Boolean> deleteResume(Integer id) {
        if(resumeRepository.findById(id).isEmpty()) {
            return R.error(false, "该简历不存在!");
        }
        resumeRepository.deleteById(id);
        return R.success(true);
    }

    /**
     * 获取所有简历信息
     */
    public R<List<ResumeInfo>> all() {
        List<Resume> resumes = resumeRepository.findAll();
        List<ResumeInfo> infos = new ArrayList<>();
        resumes.forEach(resume -> {
            ResumeInfo resumeInfo = getResumeInfo(resume);
            infos.add(resumeInfo);
        });
        return R.success(infos);
    }

    public List<Resume> findAllByJobIntent(String jobIntent) {
        return resumeRepository.findAllByJobIntent(jobIntent);
    }

    /**
     * 根据简历获取简历信息
     */
    public ResumeInfo getResumeInfo(Resume resume) {
        ResumeInfo resumeInfo = new ResumeInfo();
        /* 拷贝简历信息 */
        resumeInfo.setId(resume.getId());
        resumeInfo.setName(resume.getName());
        resumeInfo.setGender(resume.getGender());
        resumeInfo.setAge(resume.getAge());
        resumeInfo.setJobIntent(resume.getJobIntent());
        resumeInfo.setHighestEducation(resume.getHighestEducation());
        resumeInfo.setGraduateSchool(resume.getGraduateSchool());
        resumeInfo.setGraduateYear(resume.getGraduateYear());
        resumeInfo.setStudyExperiences(studyExperienceRepository.findAllByResumeId(resume.getId()));
        resumeInfo.setWorkExperiences(workExperienceRepository.findAllByResumeId(resume.getId()));
        return resumeInfo;
    }
}
